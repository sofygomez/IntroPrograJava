
package ejerciciopracticosemana6;

import javax.swing.JOptionPane;


public class EjercicioPracticoSemana6 {

    
    public static void main(String[] args) {
    
     /*Una empresa necesita determinar el monto total que debe pagar a la Caja Costarricense del
Seguro Social (CCSS). Para esto, se requiere un programa que calcule dicho monto basado en el
salario de N empleados. El programa debe solicitar la cantidad de empleados, así como los
salarios individuales, y calcular el monto total a pagar aplicando los siguientes rubros:
- Seguro de Enfermedad y Maternidad (SEM) al 9.25% del salario.
- Invalidez, Vejez y Muerte (IVM) al 5.08% del salario.
Por ejemplo, si el salario de un empleado es de ?300,000:
?300,000 x 0.0925 = ?27,750 (Monto de SEM)
?300,000 x 0.0508 = ?15,240 (Monto de IVM)
En consecuencia, la empresa deberá pagar a la CCSS un total de ?42,990.
Resultado esperado para el programa:
La empresa deberá abonar a la CCSS el monto de #####.## por concepto de SEM y IVM */
     
     
      int cantidadEmpleados = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de empleados"));

    double cantidadSem = 0;
    double cantidadIvm = 0;

    for ( int i=0; i < cantidadEmpleados ; i++) {
        
        
     double salarioEmpleado = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el salario del empleado: "));

        double calculoSem = salarioEmpleado * 0.0925;
        double calculoIvm = salarioEmpleado * 0.0508;

        cantidadSem = calculoSem + cantidadSem;
        cantidadIvm = calculoIvm + cantidadIvm;

    }//fin del for

    double cantidadTotal = cantidadSem + cantidadIvm;

    JOptionPane.showMessageDialog(null, "La empresa debera "+ "abonar a la CCSS el monto de "+cantidadTotal+" por concepto de SEM y IVM");

    }
        
        
    }
    
}
